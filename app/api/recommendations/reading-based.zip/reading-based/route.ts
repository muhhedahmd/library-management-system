import { type NextRequest, NextResponse } from "next/server"
import prisma  from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/authOption"
import { CustomSession } from "@/Types"

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions) as CustomSession
    if (!session?.user?.id) {
      return NextResponse.json({ error: "You must be logged in" }, { status: 401 })
    }

    const userId = session.user.id
    const limit = Number.parseInt(req.nextUrl.searchParams.get("limit") || "10")

    // Get user's reading history
    const readingHistory = await prisma.readingHistory.findMany({
      where: {
        userId,
        // Only consider books that were completed or had significant progress
        OR: [{ completed: true }, { pagesRead: { gt: 50 } }, { readingTimeMinutes: { gt: 30 } }],
      },
      include: {
        book: {
          select: {
            id: true,
            categoryId: true,
            authorId: true,
          },
        },
      },
      orderBy: {
        lastReadAt: "desc",
      },
    })

    // If no reading history, return popular books
    if (readingHistory.length === 0) {
      const popularBooks = await getPopularBooks(limit)
      return NextResponse.json({ recommendations: popularBooks })
    }

    // Extract category and author IDs with engagement scores
    const categoryEngagement: Record<string, number> = {}
    const authorEngagement: Record<string, number> = {}

    readingHistory.forEach((history) => {
      const categoryId = history.book.categoryId
      const authorId = history.book.authorId

      // Calculate engagement score based on reading metrics
      const engagementScore = calculateEngagementScore(history)

      // Add to category engagement
      categoryEngagement[categoryId] = (categoryEngagement[categoryId] || 0) + engagementScore

      // Add to author engagement
      authorEngagement[authorId] = (authorEngagement[authorId] || 0) + engagementScore
    })

    // Get books the user has already interacted with
    const interactedBookIds = readingHistory.map((history) => history.bookId)

    // Find books matching user's reading patterns
    const books = await prisma.book.findMany({
      where: {
        OR: [
          { categoryId: { in: Object.keys(categoryEngagement) } },
          { authorId: { in: Object.keys(authorEngagement) } },
        ],
        AND: {
          id: {
            notIn: interactedBookIds, // Exclude books the user has already read
          },
        },
      },
      include: {
        author: true,
        category: true,
        publisher: true,
        bookCovers: {
          where: {
            type: "THUMBNAIL",
          },
          take: 1,
        },
      },
    })

    // Score books based on reading history
    const scoredBooks = books.map((book) => {
      let score = 0

      // Add category engagement score
      if (categoryEngagement[book.categoryId]) {
        score += categoryEngagement[book.categoryId]
      }

      // Add author engagement score
      if (authorEngagement[book.authorId]) {
        score += authorEngagement[book.authorId] * 1.5 // Weight author more heavily
      }

      return {
        ...book,
        engagementScore: score,
      }
    })

    // Sort by engagement score and take the top results
    const recommendations = scoredBooks.sort((a, b) => b.engagementScore - a.engagementScore).slice(0, limit)

    // Log the recommendations
    await logRecommendations(userId, recommendations, "reading-based")

    return NextResponse.json({ recommendations })
  } catch (error) {
    console.error("Error getting reading-based recommendations:", error)
    return NextResponse.json({ error: "Failed to get recommendations" }, { status: 500 })
  }
}

// Calculate engagement score based on reading metrics
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function calculateEngagementScore(history: any) {
  let score = 0

  // Completed books get a high base score
  if (history.completed) {
    score += 10
  }

  // Add score based on pages read
  if (history.pagesRead) {
    score += Math.min(history.pagesRead / 50, 5) // Cap at 5 points
  }

  // Add score based on reading time
  if (history.readingTimeMinutes) {
    score += Math.min(history.readingTimeMinutes / 60, 5) // Cap at 5 points
  }

  // Recent books get a recency bonus
  const daysSinceLastRead = Math.max(
    1,
    Math.floor((Date.now() - new Date(history.lastReadAt).getTime()) / (1000 * 60 * 60 * 24)),
  )

  const recencyBonus = Math.max(0, 5 - Math.log10(daysSinceLastRead) * 2)
  score += recencyBonus

  // Abandoned books get a penalty
  if (history.abandonedAt) {
    score *= 0.3 // 70% reduction
  }

  return score
}

// Get popular books as a fallback
async function getPopularBooks(limit: number) {
  return await prisma.book.findMany({
    orderBy: {
      popularity: "desc",
    },
    include: {
      author: true,
      category: true,
      publisher: true,
      bookCovers: {
        where: {
          type: "THUMBNAIL",
        },
        take: 1,
      },
    },
    take: limit,
  })
}

// Log recommendations for analysis
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function logRecommendations(userId: string, recommendations: any[], algorithm: string) {
  try {
    await prisma.$transaction(
      recommendations.map((rec) =>
        prisma.recommendationLog.create({
          data: {
            userId,
            bookId: rec.id,
            algorithm,
            score: rec.engagementScore || 0,
          },
        }),
      ),
    )
  } catch (error) {
    console.error("Error logging recommendations:", error)
  }
}

